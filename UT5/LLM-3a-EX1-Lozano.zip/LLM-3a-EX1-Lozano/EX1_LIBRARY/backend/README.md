# API REST COURSES
- Instalar módulos
    npm install
- Arrancar servidor
    npm start

## Dependecies:
    - cors
    - express
    - mongoose
    - nodemon
    - bcryptjs

[https://developer.mozilla.org/en-US/docs/Learn/Server-side/Express_Nodejs/development_environment]!Info EXPRESS

## Endpoints
- get categories
http://localhost:8800/api/category/

- get games
http://localhost:8800/api/games/

- get one game 
http://localhost:8800/api/games/63791601e57b7c47f052fb94



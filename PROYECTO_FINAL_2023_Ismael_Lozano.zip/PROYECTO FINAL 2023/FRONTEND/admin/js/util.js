export function scrollToHash(hashName) {         
    location.hash = "#" + hashName;     
}